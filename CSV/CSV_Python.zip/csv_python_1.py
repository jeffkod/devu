import csv

csvFile = open("sprint.csv")  # opens the reader ofbject
csvReader = csv.reader(csvFile) # data object 
csvData = list(csvReader) #import the data into a list for further manipulation by python.

print(csvReader.line_num) # number of rows  directly from the reader object

'''
use this if you are not creating a list. won't work if you make a list out of data
for row in csvReader:
	print(row)

'''
#print all contents of file using list 
for row in csvData:
	print(row)

l=len(csvData)
print(csvData[1]) #print random row 
print(csvData[1][3])  #print a value
csvFile.close()

#writing to new file

csvOutFile2=open("test.csv",'w')   
outputWriter = csv.writer(csvOutFile2)
outputWriter.writerow(['name','skills','interests'])  #--First row is the 'headers' or definition of columns/arrtributes
outputWriter.writerow(['jeff','nwtworking','python']) # 2nd row onwards the data
outputWriter.writerow(['jeff2','football','basketball'])
csvOutFile2.close()

#appending
csvOutFile2=open("test.csv",'a')
outputWriter = csv.writer(csvOutFile2)
#outputWriter.writerow(['name','skills','interests'])  #--uncomment 1st time
#outputWriter.writerow(['jeff','nwtworking','python'])
#you could input the values here and add to it
outputWriter.writerow(['jeff3','excel','coding'])
csvOutFile2.close()

#

'''
#another approch of loading each row under a for loop and not using the list fn
for row in csvReader:
	print('Row #'+str(csvReader.line_num)+' '+ str(row) +'/n')

#wriing
'''
